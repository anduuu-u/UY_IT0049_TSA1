<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TasksTodaySeeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');
        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $twoDaysAgo = date('Y-m-d', strtotime('-2 days'));
        $tomorrow = date('Y-m-d', strtotime('+1 day'));

        if ($this->db->table('tasks')->countAllResults() === 0) {
            $this->db->table('tasks')->insertBatch([
                ['title' => 'Review the project requirements', 'status' => 'completed', 'task_date' => $twoDaysAgo, 'created_at' => $now],
                ['title' => 'Prepare the weekly task summary', 'status' => 'pending', 'task_date' => $yesterday, 'created_at' => $now],
                ['title' => 'Check the team schedule', 'status' => 'completed', 'task_date' => $yesterday, 'created_at' => $now],
                ['title' => 'Plan the priorities for today', 'status' => 'completed', 'task_date' => $today, 'created_at' => $now],
                ['title' => 'Update the project task list', 'status' => 'pending', 'task_date' => $today, 'created_at' => $now],
                ['title' => 'Send the progress update', 'status' => 'pending', 'task_date' => $today, 'created_at' => $now],
                ['title' => 'Organize reference materials', 'status' => 'pending', 'task_date' => $today, 'created_at' => $now],
                ['title' => 'Draft tomorrow’s work plan', 'status' => 'pending', 'task_date' => $tomorrow, 'created_at' => $now],
            ]);
        }

        if ($this->db->table('users')->countAllResults() === 0) {
            $this->db->table('users')->insert([
                'username' => 'andrew',
                'full_name' => 'Andrew James Uy',
                'email' => 'andrew.uy@example.com',
                'created_at' => $now,
            ]);
        }
    }
}
