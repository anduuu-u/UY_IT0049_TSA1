<?php

namespace App\Controllers;

use App\Models\UserModel;

class Profile extends BaseController
{
    public function index(): string
    {
        $user = (new UserModel())->getDemoUser();

        return view('pages/profile', [
            'title' => 'Profile',
            'activePage' => 'profile',
            'user' => $user,
        ]);
    }
}
