<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Home extends BaseController
{
    public function index(): string
    {
        $taskModel = new TaskModel();
        $today = date('Y-m-d');

        return view('pages/home', [
            'title' => 'Today',
            'activePage' => 'home',
            'tasks' => $taskModel->getTasksForDate($today),
            'today' => $today,
        ]);
    }
}
