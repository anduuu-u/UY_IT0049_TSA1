<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f8fc">
    <title><?= esc($title) ?> · Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <div class="nav-label">WORKSPACE</div>

        <nav class="main-nav" aria-label="Main navigation">
            <a class="nav-link <?= $activePage === 'home' ? 'active' : '' ?>" href="<?= site_url('/') ?>">
                <span class="nav-icon">◷</span>Today
            </a>
            <a class="nav-link <?= $activePage === 'tasks' ? 'active' : '' ?>" href="<?= site_url('tasks') ?>">
                <span class="nav-icon">▤</span>All tasks
            </a>
            <a class="nav-link <?= $activePage === 'profile' ? 'active' : '' ?>" href="<?= site_url('profile') ?>">
                <span class="nav-icon">♙</span>Profile
            </a>
            <a class="nav-link <?= $activePage === 'about' ? 'active' : '' ?>" href="<?= site_url('about') ?>">
                <span class="nav-icon">ⓘ</span>About
            </a>
        </nav>

        <div class="sidebar-bottom">
            <div class="sidebar-note">
                <span class="note-dot"></span>
                <div>
                    <strong>A little progress</strong>
                    <small>goes a long way.</small>
                </div>
            </div>
            <div class="sidebar-version">IT0049 · TSA 1</div>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="breadcrumb">Workspace <span>/</span> <?= esc($title) ?></div>
            <a class="top-profile" href="<?= site_url('profile') ?>">
                <span class="mini-avatar">A</span>
                <span>Andrew</span>
                <span class="chevron">⌄</span>
            </a>
        </header>

        <div class="page-content">
            <?= $this->renderSection('content') ?>
        </div>

        <footer class="footer">
            <span>Tasks for Today</span>
            <span>Make room for what matters.</span>
        </footer>
    </main>
</div>
</body>
</html>