<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<section class="welcome-row compact-row"><div><div class="eyebrow"><span class="eyebrow-line"></span> YOUR WORKSPACE</div><h1>All <span>tasks.</span></h1><p class="page-lead">Every item, collected in one place and sorted by date.</p></div><div class="count-chip"><strong><?= count($tasks) ?></strong><span>total tasks</span></div></section>
<section class="section-heading list-heading"><div><div class="eyebrow">THE COMPLETE LIST</div><h2>Task history</h2></div><span class="sorted-label">↕ &nbsp;Sorted by date</span></section>
<section class="task-card">
    <?php if (empty($tasks)): ?>
        <div class="empty-state"><div class="empty-icon">✦</div><h3>Your list is ready.</h3><p>There are no tasks in the database yet.</p></div>
    <?php else: ?>
        <?php $lastDate = null; foreach ($tasks as $index => $task): ?>
            <?php if ($lastDate !== $task['task_date']): $lastDate = $task['task_date']; ?>
                <div class="date-divider"><span><?= esc(date('F j, Y', strtotime($task['task_date']))) ?></span><?php if ($task['task_date'] === date('Y-m-d')): ?><span class="today-tag">TODAY</span><?php endif ?></div>
            <?php endif ?>
            <article class="task-row"><div class="task-check <?= $task['status'] === 'completed' ? 'is-done' : '' ?>"><?= $task['status'] === 'completed' ? '✓' : '' ?></div><div class="task-copy"><h3 class="<?= $task['status'] === 'completed' ? 'is-complete' : '' ?>"><?= esc($task['title']) ?></h3><p><?= esc(date('D, M j', strtotime($task['task_date']))) ?></p></div><span class="status-pill <?= $task['status'] === 'completed' ? 'status-done' : 'status-pending' ?>"><span></span><?= esc(ucfirst($task['status'])) ?></span><span class="row-number"><?= str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT) ?></span></article>
        <?php endforeach ?>
    <?php endif ?>
</section>
<?= $this->endSection() ?>
