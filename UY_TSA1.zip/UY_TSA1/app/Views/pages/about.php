<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<section class="welcome-row compact-row"><div><div class="eyebrow">
    <span class="eyebrow-line"></span> A LITTLE CONTEXT</div>
    <h1>Built for <span>better days.</span>
</h1><p class="page-lead">Simple tools can make daily work feel more manageable.</p>
</div>
</section>
<section class="about-card"><div class="about-icon">D</div><div class="about-copy"><div class="eyebrow">ABOUT THIS PROJECT</div><h2>Tasks for Today<br>Management System</h2><p>Hi Sir! I chose to name this project Daymark :D. Daymark is a small task management system created for this IT0049 Technical Summative Assessment 1. It brings today’s priorities into focus while keeping the complete task list easy to review.</p><p>The project demonstrates a CodeIgniter 4 MVC structure, database migrations and seed data, and separate views for today’s tasks, the full task list, a user profile, and this About page.</p><div class="about-credit"><span class="credit-avatar">AU</span><div><small>DESIGNED & BUILT BY</small><strong>Andrew James Uy</strong><span>Student developer · IT0049</span></div></div></div><div class="about-side"><span class="side-star">✳</span><span>One thoughtful<br>step at a time.</span></div></section>
<section class="tech-strip"><span>MADE WITH</span><div><b>CodeIgniter 4</b><i></i><b>PHP</b><i></i><b>MySQL</b></div><span class="version">TSA 1 · 2026</span></section>
<?= $this->endSection() ?>
