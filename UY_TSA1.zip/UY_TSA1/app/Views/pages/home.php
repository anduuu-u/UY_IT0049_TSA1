<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<section class="welcome-row">
    <div>
        <div class="eyebrow"><span class="eyebrow-line"></span> YOUR DAILY OVERVIEW</div>
        <h1>Make today <span>count.</span></h1>
        <p class="page-lead">A clear list for a calmer, more focused day.</p>
    </div>
    <div class="date-chip"><span class="calendar-icon">▦</span><span><?= esc(date('l, F j, Y', strtotime($today))) ?></span></div>
</section>
<section class="summary-grid">
    <article class="summary-card"><div class="summary-top"><span>ON YOUR LIST</span><span class="summary-icon lavender">▤</span></div><div class="summary-number"><?= count($tasks) ?></div><div class="summary-caption">tasks scheduled for today</div></article>
    <article class="summary-card"><div class="summary-top"><span>COMPLETED</span><span class="summary-icon mint">✓</span></div><div class="summary-number"><?= count(array_filter($tasks, static fn ($task) => $task['status'] === 'completed')) ?></div><div class="summary-caption">small wins already made</div></article>
    <article class="summary-card accent-card"><div class="sparkle">✳</div><div class="accent-label">A NOTE FOR TODAY</div><p>Focus on the next step.<br>Momentum will follow.</p><span class="accent-byline">— your Daymark reminder</span></article>
</section>
<section class="section-heading"><div><div class="eyebrow">THE PLAN</div><h2>Today’s tasks</h2></div><a class="text-link" href="<?= site_url('tasks') ?>">View all tasks <span>→</span></a></section>
<section class="task-card">
    <?php if (empty($tasks)): ?>
        <div class="empty-state"><div class="empty-icon">✦</div><h3>A little breathing room.</h3><p>There are no tasks scheduled for today.</p></div>
    <?php else: ?>
        <?php foreach ($tasks as $index => $task): ?>
            <article class="task-row"><div class="task-check <?= $task['status'] === 'completed' ? 'is-done' : '' ?>"><?= $task['status'] === 'completed' ? '✓' : '' ?></div><div class="task-copy"><h3 class="<?= $task['status'] === 'completed' ? 'is-complete' : '' ?>"><?= esc($task['title']) ?></h3><p>Added to today’s plan</p></div><span class="status-pill <?= $task['status'] === 'completed' ? 'status-done' : 'status-pending' ?>"><span></span><?= esc(ucfirst($task['status'])) ?></span><span class="row-number"><?= str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT) ?></span></article>
        <?php endforeach ?>
    <?php endif ?>
</section>
<?= $this->endSection() ?>
